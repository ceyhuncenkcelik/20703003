﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Proje2
{
    public class Nakit:Odeme
    {
        public int OdenecekUcret { get; set; }
       public override  void OdemeYap() {
           

        }
        
    }
}
