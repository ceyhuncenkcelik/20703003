﻿
namespace Proje2
{
    partial class Musterimenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Musterimenu));
            this.sapkabutton = new System.Windows.Forms.Button();
            this.ayakkabıbutton = new System.Windows.Forms.Button();
            this.pantolonbutton = new System.Windows.Forms.Button();
            this.saatbutton = new System.Windows.Forms.Button();
            this.gomlekbutton = new System.Windows.Forms.Button();
            this.gozlukbutton = new System.Windows.Forms.Button();
            this.ürünlerlbl = new System.Windows.Forms.Label();
            this.lblSapkaAgirlik = new System.Windows.Forms.Label();
            this.lblSapkaFiyat = new System.Windows.Forms.Label();
            this.lblAyakkabiAgirlik = new System.Windows.Forms.Label();
            this.lblAyakkabiFiyat = new System.Windows.Forms.Label();
            this.lblGomlekAgirlik = new System.Windows.Forms.Label();
            this.lblGomlekFiyat = new System.Windows.Forms.Label();
            this.lblPantolonAgirlik = new System.Windows.Forms.Label();
            this.lblPantolonFiyat = new System.Windows.Forms.Label();
            this.lblSaatAgirlik = new System.Windows.Forms.Label();
            this.lblSaatFiyat = new System.Windows.Forms.Label();
            this.lblGozlukAgirlik = new System.Windows.Forms.Label();
            this.lblGozlukFiyat = new System.Windows.Forms.Label();
            this.sepetimbutton = new System.Windows.Forms.Button();
            this.ürüneklebutton = new System.Windows.Forms.Button();
            this.musterimenutextbox = new System.Windows.Forms.TextBox();
            this.siparisOtomasyonuDataSet = new Proje2.SiparisOtomasyonuDataSet();
            this.tblUrunlerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tbl_UrunlerTableAdapter = new Proje2.SiparisOtomasyonuDataSetTableAdapters.Tbl_UrunlerTableAdapter();
            this.siparisOtomasyonuDataSet1 = new Proje2.SiparisOtomasyonuDataSet1();
            this.tblUrunlerBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.tbl_UrunlerTableAdapter1 = new Proje2.SiparisOtomasyonuDataSet1TableAdapters.Tbl_UrunlerTableAdapter();
            this.lblUrunAciklama = new System.Windows.Forms.Label();
            this.siparisOtomasyonuDataSet2 = new Proje2.SiparisOtomasyonuDataSet2();
            this.tblUrunlerBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.tbl_UrunlerTableAdapter2 = new Proje2.SiparisOtomasyonuDataSet2TableAdapters.Tbl_UrunlerTableAdapter();
            this.grpboxUrunAciklama = new System.Windows.Forms.GroupBox();
            this.lblUrunAdedi = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.siparisOtomasyonuDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblUrunlerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.siparisOtomasyonuDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblUrunlerBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.siparisOtomasyonuDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblUrunlerBindingSource2)).BeginInit();
            this.grpboxUrunAciklama.SuspendLayout();
            this.SuspendLayout();
            // 
            // sapkabutton
            // 
            this.sapkabutton.BackColor = System.Drawing.Color.White;
            this.sapkabutton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("sapkabutton.BackgroundImage")));
            this.sapkabutton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.sapkabutton.Location = new System.Drawing.Point(159, 115);
            this.sapkabutton.Margin = new System.Windows.Forms.Padding(5);
            this.sapkabutton.Name = "sapkabutton";
            this.sapkabutton.Size = new System.Drawing.Size(126, 103);
            this.sapkabutton.TabIndex = 0;
            this.sapkabutton.UseVisualStyleBackColor = false;
            this.sapkabutton.Click += new System.EventHandler(this.sapkabutton_Click_1);
            // 
            // ayakkabıbutton
            // 
            this.ayakkabıbutton.BackColor = System.Drawing.Color.White;
            this.ayakkabıbutton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ayakkabıbutton.BackgroundImage")));
            this.ayakkabıbutton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ayakkabıbutton.ForeColor = System.Drawing.Color.White;
            this.ayakkabıbutton.Location = new System.Drawing.Point(372, 115);
            this.ayakkabıbutton.Margin = new System.Windows.Forms.Padding(5);
            this.ayakkabıbutton.Name = "ayakkabıbutton";
            this.ayakkabıbutton.Size = new System.Drawing.Size(112, 103);
            this.ayakkabıbutton.TabIndex = 1;
            this.ayakkabıbutton.UseVisualStyleBackColor = false;
            this.ayakkabıbutton.Click += new System.EventHandler(this.ayakkabıbutton_Click);
            // 
            // pantolonbutton
            // 
            this.pantolonbutton.BackColor = System.Drawing.Color.White;
            this.pantolonbutton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pantolonbutton.BackgroundImage")));
            this.pantolonbutton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pantolonbutton.Location = new System.Drawing.Point(159, 365);
            this.pantolonbutton.Margin = new System.Windows.Forms.Padding(5);
            this.pantolonbutton.Name = "pantolonbutton";
            this.pantolonbutton.Size = new System.Drawing.Size(126, 100);
            this.pantolonbutton.TabIndex = 2;
            this.pantolonbutton.UseVisualStyleBackColor = false;
            this.pantolonbutton.Click += new System.EventHandler(this.pantolonbutton_Click);
            // 
            // saatbutton
            // 
            this.saatbutton.BackColor = System.Drawing.Color.White;
            this.saatbutton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("saatbutton.BackgroundImage")));
            this.saatbutton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.saatbutton.Location = new System.Drawing.Point(372, 365);
            this.saatbutton.Margin = new System.Windows.Forms.Padding(5);
            this.saatbutton.Name = "saatbutton";
            this.saatbutton.Size = new System.Drawing.Size(112, 100);
            this.saatbutton.TabIndex = 3;
            this.saatbutton.UseVisualStyleBackColor = false;
            this.saatbutton.Click += new System.EventHandler(this.saatbutton_Click);
            // 
            // gomlekbutton
            // 
            this.gomlekbutton.BackColor = System.Drawing.Color.White;
            this.gomlekbutton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("gomlekbutton.BackgroundImage")));
            this.gomlekbutton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.gomlekbutton.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.gomlekbutton.Location = new System.Drawing.Point(592, 115);
            this.gomlekbutton.Margin = new System.Windows.Forms.Padding(5);
            this.gomlekbutton.Name = "gomlekbutton";
            this.gomlekbutton.Size = new System.Drawing.Size(107, 103);
            this.gomlekbutton.TabIndex = 4;
            this.gomlekbutton.UseVisualStyleBackColor = false;
            this.gomlekbutton.Click += new System.EventHandler(this.gomlekbutton_Click);
            // 
            // gozlukbutton
            // 
            this.gozlukbutton.BackColor = System.Drawing.Color.White;
            this.gozlukbutton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("gozlukbutton.BackgroundImage")));
            this.gozlukbutton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.gozlukbutton.Location = new System.Drawing.Point(587, 365);
            this.gozlukbutton.Margin = new System.Windows.Forms.Padding(5);
            this.gozlukbutton.Name = "gozlukbutton";
            this.gozlukbutton.Size = new System.Drawing.Size(118, 100);
            this.gozlukbutton.TabIndex = 5;
            this.gozlukbutton.UseVisualStyleBackColor = false;
            this.gozlukbutton.Visible = false;
            this.gozlukbutton.Click += new System.EventHandler(this.gozlukbutton_Click);
            // 
            // ürünlerlbl
            // 
            this.ürünlerlbl.AutoSize = true;
            this.ürünlerlbl.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ürünlerlbl.Location = new System.Drawing.Point(153, 43);
            this.ürünlerlbl.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.ürünlerlbl.Name = "ürünlerlbl";
            this.ürünlerlbl.Size = new System.Drawing.Size(130, 28);
            this.ürünlerlbl.TabIndex = 7;
            this.ürünlerlbl.Text = "ÜRÜNLER";
            // 
            // lblSapkaAgirlik
            // 
            this.lblSapkaAgirlik.AutoSize = true;
            this.lblSapkaAgirlik.Location = new System.Drawing.Point(204, 257);
            this.lblSapkaAgirlik.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblSapkaAgirlik.Name = "lblSapkaAgirlik";
            this.lblSapkaAgirlik.Size = new System.Drawing.Size(45, 25);
            this.lblSapkaAgirlik.TabIndex = 8;
            this.lblSapkaAgirlik.Text = "200";
            // 
            // lblSapkaFiyat
            // 
            this.lblSapkaFiyat.AutoSize = true;
            this.lblSapkaFiyat.Location = new System.Drawing.Point(204, 304);
            this.lblSapkaFiyat.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblSapkaFiyat.Name = "lblSapkaFiyat";
            this.lblSapkaFiyat.Size = new System.Drawing.Size(34, 25);
            this.lblSapkaFiyat.TabIndex = 9;
            this.lblSapkaFiyat.Text = "60";
            // 
            // lblAyakkabiAgirlik
            // 
            this.lblAyakkabiAgirlik.AutoSize = true;
            this.lblAyakkabiAgirlik.Location = new System.Drawing.Point(399, 257);
            this.lblAyakkabiAgirlik.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblAyakkabiAgirlik.Name = "lblAyakkabiAgirlik";
            this.lblAyakkabiAgirlik.Size = new System.Drawing.Size(45, 25);
            this.lblAyakkabiAgirlik.TabIndex = 10;
            this.lblAyakkabiAgirlik.Text = "500";
            // 
            // lblAyakkabiFiyat
            // 
            this.lblAyakkabiFiyat.AutoSize = true;
            this.lblAyakkabiFiyat.Location = new System.Drawing.Point(399, 304);
            this.lblAyakkabiFiyat.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblAyakkabiFiyat.Name = "lblAyakkabiFiyat";
            this.lblAyakkabiFiyat.Size = new System.Drawing.Size(45, 25);
            this.lblAyakkabiFiyat.TabIndex = 11;
            this.lblAyakkabiFiyat.Text = "250";
            // 
            // lblGomlekAgirlik
            // 
            this.lblGomlekAgirlik.AutoSize = true;
            this.lblGomlekAgirlik.Location = new System.Drawing.Point(612, 257);
            this.lblGomlekAgirlik.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblGomlekAgirlik.Name = "lblGomlekAgirlik";
            this.lblGomlekAgirlik.Size = new System.Drawing.Size(45, 25);
            this.lblGomlekAgirlik.TabIndex = 12;
            this.lblGomlekAgirlik.Text = "300";
            // 
            // lblGomlekFiyat
            // 
            this.lblGomlekFiyat.AutoSize = true;
            this.lblGomlekFiyat.Location = new System.Drawing.Point(620, 304);
            this.lblGomlekFiyat.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblGomlekFiyat.Name = "lblGomlekFiyat";
            this.lblGomlekFiyat.Size = new System.Drawing.Size(33, 25);
            this.lblGomlekFiyat.TabIndex = 13;
            this.lblGomlekFiyat.Text = "70";
            // 
            // lblPantolonAgirlik
            // 
            this.lblPantolonAgirlik.AutoSize = true;
            this.lblPantolonAgirlik.Location = new System.Drawing.Point(204, 488);
            this.lblPantolonAgirlik.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblPantolonAgirlik.Name = "lblPantolonAgirlik";
            this.lblPantolonAgirlik.Size = new System.Drawing.Size(45, 25);
            this.lblPantolonAgirlik.TabIndex = 14;
            this.lblPantolonAgirlik.Text = "400";
            // 
            // lblPantolonFiyat
            // 
            this.lblPantolonFiyat.AutoSize = true;
            this.lblPantolonFiyat.Location = new System.Drawing.Point(204, 529);
            this.lblPantolonFiyat.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblPantolonFiyat.Name = "lblPantolonFiyat";
            this.lblPantolonFiyat.Size = new System.Drawing.Size(34, 25);
            this.lblPantolonFiyat.TabIndex = 15;
            this.lblPantolonFiyat.Text = "90";
            // 
            // lblSaatAgirlik
            // 
            this.lblSaatAgirlik.AutoSize = true;
            this.lblSaatAgirlik.Location = new System.Drawing.Point(399, 488);
            this.lblSaatAgirlik.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblSaatAgirlik.Name = "lblSaatAgirlik";
            this.lblSaatAgirlik.Size = new System.Drawing.Size(42, 25);
            this.lblSaatAgirlik.TabIndex = 16;
            this.lblSaatAgirlik.Text = "100";
            // 
            // lblSaatFiyat
            // 
            this.lblSaatFiyat.AutoSize = true;
            this.lblSaatFiyat.Location = new System.Drawing.Point(397, 529);
            this.lblSaatFiyat.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblSaatFiyat.Name = "lblSaatFiyat";
            this.lblSaatFiyat.Size = new System.Drawing.Size(53, 25);
            this.lblSaatFiyat.TabIndex = 17;
            this.lblSaatFiyat.Text = "1000";
            // 
            // lblGozlukAgirlik
            // 
            this.lblGozlukAgirlik.AutoSize = true;
            this.lblGozlukAgirlik.Location = new System.Drawing.Point(632, 488);
            this.lblGozlukAgirlik.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblGozlukAgirlik.Name = "lblGozlukAgirlik";
            this.lblGozlukAgirlik.Size = new System.Drawing.Size(33, 25);
            this.lblGozlukAgirlik.TabIndex = 18;
            this.lblGozlukAgirlik.Text = "75";
            this.lblGozlukAgirlik.Visible = false;
            // 
            // lblGozlukFiyat
            // 
            this.lblGozlukFiyat.AutoSize = true;
            this.lblGozlukFiyat.Location = new System.Drawing.Point(620, 529);
            this.lblGozlukFiyat.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblGozlukFiyat.Name = "lblGozlukFiyat";
            this.lblGozlukFiyat.Size = new System.Drawing.Size(45, 25);
            this.lblGozlukFiyat.TabIndex = 19;
            this.lblGozlukFiyat.Text = "300";
            this.lblGozlukFiyat.Visible = false;
            // 
            // sepetimbutton
            // 
            this.sepetimbutton.BackColor = System.Drawing.Color.LightSlateGray;
            this.sepetimbutton.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold);
            this.sepetimbutton.Location = new System.Drawing.Point(807, 212);
            this.sepetimbutton.Margin = new System.Windows.Forms.Padding(5);
            this.sepetimbutton.Name = "sepetimbutton";
            this.sepetimbutton.Size = new System.Drawing.Size(388, 77);
            this.sepetimbutton.TabIndex = 20;
            this.sepetimbutton.Text = "Sepetim";
            this.sepetimbutton.UseVisualStyleBackColor = false;
            this.sepetimbutton.Click += new System.EventHandler(this.sepetimbutton_Click);
            // 
            // ürüneklebutton
            // 
            this.ürüneklebutton.BackColor = System.Drawing.Color.LightSlateGray;
            this.ürüneklebutton.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold);
            this.ürüneklebutton.Location = new System.Drawing.Point(1013, 115);
            this.ürüneklebutton.Margin = new System.Windows.Forms.Padding(5);
            this.ürüneklebutton.Name = "ürüneklebutton";
            this.ürüneklebutton.Size = new System.Drawing.Size(182, 76);
            this.ürüneklebutton.TabIndex = 21;
            this.ürüneklebutton.Text = "Sepete Ekle";
            this.ürüneklebutton.UseVisualStyleBackColor = false;
            this.ürüneklebutton.Click += new System.EventHandler(this.ürüneklebutton_Click);
            // 
            // musterimenutextbox
            // 
            this.musterimenutextbox.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold);
            this.musterimenutextbox.ForeColor = System.Drawing.SystemColors.WindowText;
            this.musterimenutextbox.Location = new System.Drawing.Point(807, 152);
            this.musterimenutextbox.Margin = new System.Windows.Forms.Padding(5);
            this.musterimenutextbox.Name = "musterimenutextbox";
            this.musterimenutextbox.Size = new System.Drawing.Size(196, 33);
            this.musterimenutextbox.TabIndex = 22;
            // 
            // siparisOtomasyonuDataSet
            // 
            this.siparisOtomasyonuDataSet.DataSetName = "SiparisOtomasyonuDataSet";
            this.siparisOtomasyonuDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblUrunlerBindingSource
            // 
            this.tblUrunlerBindingSource.DataMember = "Tbl_Urunler";
            this.tblUrunlerBindingSource.DataSource = this.siparisOtomasyonuDataSet;
            // 
            // tbl_UrunlerTableAdapter
            // 
            this.tbl_UrunlerTableAdapter.ClearBeforeFill = true;
            // 
            // siparisOtomasyonuDataSet1
            // 
            this.siparisOtomasyonuDataSet1.DataSetName = "SiparisOtomasyonuDataSet1";
            this.siparisOtomasyonuDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblUrunlerBindingSource1
            // 
            this.tblUrunlerBindingSource1.DataMember = "Tbl_Urunler";
            this.tblUrunlerBindingSource1.DataSource = this.siparisOtomasyonuDataSet1;
            // 
            // tbl_UrunlerTableAdapter1
            // 
            this.tbl_UrunlerTableAdapter1.ClearBeforeFill = true;
            // 
            // lblUrunAciklama
            // 
            this.lblUrunAciklama.AutoSize = true;
            this.lblUrunAciklama.Location = new System.Drawing.Point(24, 45);
            this.lblUrunAciklama.Name = "lblUrunAciklama";
            this.lblUrunAciklama.Size = new System.Drawing.Size(0, 25);
            this.lblUrunAciklama.TabIndex = 28;
            // 
            // siparisOtomasyonuDataSet2
            // 
            this.siparisOtomasyonuDataSet2.DataSetName = "SiparisOtomasyonuDataSet2";
            this.siparisOtomasyonuDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblUrunlerBindingSource2
            // 
            this.tblUrunlerBindingSource2.DataMember = "Tbl_Urunler";
            this.tblUrunlerBindingSource2.DataSource = this.siparisOtomasyonuDataSet2;
            // 
            // tbl_UrunlerTableAdapter2
            // 
            this.tbl_UrunlerTableAdapter2.ClearBeforeFill = true;
            // 
            // grpboxUrunAciklama
            // 
            this.grpboxUrunAciklama.Controls.Add(this.lblUrunAciklama);
            this.grpboxUrunAciklama.Location = new System.Drawing.Point(807, 336);
            this.grpboxUrunAciklama.Name = "grpboxUrunAciklama";
            this.grpboxUrunAciklama.Size = new System.Drawing.Size(388, 148);
            this.grpboxUrunAciklama.TabIndex = 29;
            this.grpboxUrunAciklama.TabStop = false;
            this.grpboxUrunAciklama.Text = "Ürün Açıklama";
            // 
            // lblUrunAdedi
            // 
            this.lblUrunAdedi.AutoSize = true;
            this.lblUrunAdedi.Location = new System.Drawing.Point(810, 115);
            this.lblUrunAdedi.Name = "lblUrunAdedi";
            this.lblUrunAdedi.Size = new System.Drawing.Size(114, 25);
            this.lblUrunAdedi.TabIndex = 30;
            this.lblUrunAdedi.Text = "Ürün Adedi:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(71, 257);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 25);
            this.label1.TabIndex = 31;
            this.label1.Text = "Ağırlık";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(85, 304);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 25);
            this.label2.TabIndex = 32;
            this.label2.Text = "Fiyat";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(76, 488);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 25);
            this.label3.TabIndex = 33;
            this.label3.Text = "Ağırlık";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(85, 529);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 25);
            this.label4.TabIndex = 34;
            this.label4.Text = "Fiyat";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(855, 518);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(266, 25);
            this.label5.TabIndex = 35;
            this.label5.Text = "Yeni sezon eklenecek Urunler:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(955, 567);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 25);
            this.label6.TabIndex = 36;
            this.label6.Text = "Gozluk";
            // 
            // Musterimenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.BurlyWood;
            this.ClientSize = new System.Drawing.Size(1284, 750);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblUrunAdedi);
            this.Controls.Add(this.grpboxUrunAciklama);
            this.Controls.Add(this.musterimenutextbox);
            this.Controls.Add(this.ürüneklebutton);
            this.Controls.Add(this.sepetimbutton);
            this.Controls.Add(this.lblGozlukFiyat);
            this.Controls.Add(this.lblGozlukAgirlik);
            this.Controls.Add(this.lblSaatFiyat);
            this.Controls.Add(this.lblSaatAgirlik);
            this.Controls.Add(this.lblPantolonFiyat);
            this.Controls.Add(this.lblPantolonAgirlik);
            this.Controls.Add(this.lblGomlekFiyat);
            this.Controls.Add(this.lblGomlekAgirlik);
            this.Controls.Add(this.lblAyakkabiFiyat);
            this.Controls.Add(this.lblAyakkabiAgirlik);
            this.Controls.Add(this.lblSapkaFiyat);
            this.Controls.Add(this.lblSapkaAgirlik);
            this.Controls.Add(this.ürünlerlbl);
            this.Controls.Add(this.gozlukbutton);
            this.Controls.Add(this.gomlekbutton);
            this.Controls.Add(this.saatbutton);
            this.Controls.Add(this.pantolonbutton);
            this.Controls.Add(this.ayakkabıbutton);
            this.Controls.Add(this.sapkabutton);
            this.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold);
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "Musterimenu";
            this.Text = "Musterimenu";
            this.Load += new System.EventHandler(this.Musterimenu_Load);
            ((System.ComponentModel.ISupportInitialize)(this.siparisOtomasyonuDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblUrunlerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.siparisOtomasyonuDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblUrunlerBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.siparisOtomasyonuDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblUrunlerBindingSource2)).EndInit();
            this.grpboxUrunAciklama.ResumeLayout(false);
            this.grpboxUrunAciklama.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button sapkabutton;
        private System.Windows.Forms.Button pantolonbutton;
        private System.Windows.Forms.Button saatbutton;
        private System.Windows.Forms.Label ürünlerlbl;
        private System.Windows.Forms.Button sepetimbutton;
        private System.Windows.Forms.Button ürüneklebutton;
        private System.Windows.Forms.TextBox musterimenutextbox;
        private SiparisOtomasyonuDataSet siparisOtomasyonuDataSet;
        private System.Windows.Forms.BindingSource tblUrunlerBindingSource;
        private SiparisOtomasyonuDataSetTableAdapters.Tbl_UrunlerTableAdapter tbl_UrunlerTableAdapter;
        private SiparisOtomasyonuDataSet1 siparisOtomasyonuDataSet1;
        private System.Windows.Forms.BindingSource tblUrunlerBindingSource1;
        private SiparisOtomasyonuDataSet1TableAdapters.Tbl_UrunlerTableAdapter tbl_UrunlerTableAdapter1;
        private System.Windows.Forms.Label lblUrunAciklama;
        private SiparisOtomasyonuDataSet2 siparisOtomasyonuDataSet2;
        private System.Windows.Forms.BindingSource tblUrunlerBindingSource2;
        private SiparisOtomasyonuDataSet2TableAdapters.Tbl_UrunlerTableAdapter tbl_UrunlerTableAdapter2;
        private System.Windows.Forms.GroupBox grpboxUrunAciklama;
        private System.Windows.Forms.Label lblUrunAdedi;
        public System.Windows.Forms.Label lblAyakkabiAgirlik;
        public System.Windows.Forms.Button ayakkabıbutton;
        public System.Windows.Forms.Button gomlekbutton;
        public System.Windows.Forms.Label lblSapkaAgirlik;
        public System.Windows.Forms.Label lblSapkaFiyat;
        public System.Windows.Forms.Label lblAyakkabiFiyat;
        public System.Windows.Forms.Label lblGomlekAgirlik;
        public System.Windows.Forms.Label lblGomlekFiyat;
        public System.Windows.Forms.Label lblPantolonAgirlik;
        public System.Windows.Forms.Label lblPantolonFiyat;
        public System.Windows.Forms.Label lblSaatAgirlik;
        public System.Windows.Forms.Label lblSaatFiyat;
        public System.Windows.Forms.Label lblGozlukAgirlik;
        public System.Windows.Forms.Label lblGozlukFiyat;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        public System.Windows.Forms.Button gozlukbutton;
    }
}