﻿
namespace Proje2
{
    partial class sepetim
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listeyitemizlebutton = new System.Windows.Forms.Button();
            this.ödemebutton = new System.Windows.Forms.Button();
            this.ürünismilbl = new System.Windows.Forms.Label();
            this.ürünfiaytılbl = new System.Windows.Forms.Label();
            this.ürünadedilbl = new System.Windows.Forms.Label();
            this.sepetimlistbox = new System.Windows.Forms.ListBox();
            this.alısverisedevametbutton = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.lblUrunAgirligi = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // listeyitemizlebutton
            // 
            this.listeyitemizlebutton.BackColor = System.Drawing.Color.LightSlateGray;
            this.listeyitemizlebutton.Location = new System.Drawing.Point(277, 322);
            this.listeyitemizlebutton.Name = "listeyitemizlebutton";
            this.listeyitemizlebutton.Size = new System.Drawing.Size(224, 57);
            this.listeyitemizlebutton.TabIndex = 1;
            this.listeyitemizlebutton.Text = "Listeyi Temizle";
            this.listeyitemizlebutton.UseVisualStyleBackColor = false;
            this.listeyitemizlebutton.Click += new System.EventHandler(this.listeyitemizlebutton_Click);
            // 
            // ödemebutton
            // 
            this.ödemebutton.BackColor = System.Drawing.Color.LightSlateGray;
            this.ödemebutton.Location = new System.Drawing.Point(526, 322);
            this.ödemebutton.Name = "ödemebutton";
            this.ödemebutton.Size = new System.Drawing.Size(224, 57);
            this.ödemebutton.TabIndex = 2;
            this.ödemebutton.Text = "Ödeme Menüsü";
            this.ödemebutton.UseVisualStyleBackColor = false;
            this.ödemebutton.Click += new System.EventHandler(this.ödemebutton_Click);
            // 
            // ürünismilbl
            // 
            this.ürünismilbl.AutoSize = true;
            this.ürünismilbl.Location = new System.Drawing.Point(47, 29);
            this.ürünismilbl.Name = "ürünismilbl";
            this.ürünismilbl.Size = new System.Drawing.Size(94, 25);
            this.ürünismilbl.TabIndex = 3;
            this.ürünismilbl.Text = "Ürün ismi";
            // 
            // ürünfiaytılbl
            // 
            this.ürünfiaytılbl.AutoSize = true;
            this.ürünfiaytılbl.Location = new System.Drawing.Point(201, 29);
            this.ürünfiaytılbl.Name = "ürünfiaytılbl";
            this.ürünfiaytılbl.Size = new System.Drawing.Size(103, 25);
            this.ürünfiaytılbl.TabIndex = 4;
            this.ürünfiaytılbl.Text = "Ürün fiyatı";
            // 
            // ürünadedilbl
            // 
            this.ürünadedilbl.AutoSize = true;
            this.ürünadedilbl.Location = new System.Drawing.Point(561, 29);
            this.ürünadedilbl.Name = "ürünadedilbl";
            this.ürünadedilbl.Size = new System.Drawing.Size(106, 25);
            this.ürünadedilbl.TabIndex = 5;
            this.ürünadedilbl.Text = "Ürün adedi";
            // 
            // sepetimlistbox
            // 
            this.sepetimlistbox.FormattingEnabled = true;
            this.sepetimlistbox.ItemHeight = 25;
            this.sepetimlistbox.Location = new System.Drawing.Point(25, 64);
            this.sepetimlistbox.Name = "sepetimlistbox";
            this.sepetimlistbox.Size = new System.Drawing.Size(725, 204);
            this.sepetimlistbox.TabIndex = 0;
            // 
            // alısverisedevametbutton
            // 
            this.alısverisedevametbutton.BackColor = System.Drawing.Color.LightSlateGray;
            this.alısverisedevametbutton.Location = new System.Drawing.Point(25, 385);
            this.alısverisedevametbutton.Name = "alısverisedevametbutton";
            this.alısverisedevametbutton.Size = new System.Drawing.Size(254, 54);
            this.alısverisedevametbutton.TabIndex = 6;
            this.alısverisedevametbutton.Text = "Alısverişe Devam Et";
            this.alısverisedevametbutton.UseVisualStyleBackColor = false;
            this.alısverisedevametbutton.Click += new System.EventHandler(this.alısverisedevametbutton_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.LightSlateGray;
            this.button1.Location = new System.Drawing.Point(25, 322);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(224, 57);
            this.button1.TabIndex = 7;
            this.button1.Text = "Ürünleri Listele";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblUrunAgirligi
            // 
            this.lblUrunAgirligi.AutoSize = true;
            this.lblUrunAgirligi.Location = new System.Drawing.Point(385, 29);
            this.lblUrunAgirligi.Name = "lblUrunAgirligi";
            this.lblUrunAgirligi.Size = new System.Drawing.Size(118, 25);
            this.lblUrunAgirligi.TabIndex = 8;
            this.lblUrunAgirligi.Text = "Ürün ağırlığı";
            // 
            // sepetim
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.BurlyWood;
            this.ClientSize = new System.Drawing.Size(781, 486);
            this.Controls.Add(this.lblUrunAgirligi);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.alısverisedevametbutton);
            this.Controls.Add(this.ürünadedilbl);
            this.Controls.Add(this.ürünfiaytılbl);
            this.Controls.Add(this.ürünismilbl);
            this.Controls.Add(this.ödemebutton);
            this.Controls.Add(this.listeyitemizlebutton);
            this.Controls.Add(this.sepetimlistbox);
            this.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold);
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "sepetim";
            this.Text = "Sepetim";
            this.Load += new System.EventHandler(this.sepetim_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button listeyitemizlebutton;
        private System.Windows.Forms.Button ödemebutton;
        private System.Windows.Forms.Label ürünismilbl;
        private System.Windows.Forms.Label ürünfiaytılbl;
        private System.Windows.Forms.Label ürünadedilbl;
        private System.Windows.Forms.Button alısverisedevametbutton;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lblUrunAgirligi;
        public System.Windows.Forms.ListBox sepetimlistbox;
    }
}