﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Proje2
{
    public class Cek:Odeme
    {
        public string Isim { get; set; }
        public int BankaID { get; set; }
        public override void OdemeYap()
        {
           
        }
        public override void Onayla()
        {

        }

    }
}
