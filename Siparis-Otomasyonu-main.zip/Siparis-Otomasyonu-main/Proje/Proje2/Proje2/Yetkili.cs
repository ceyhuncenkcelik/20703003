﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Proje2
{
    public class Yetkili
    {
        public string YetkiliAd { get; set; }
        public int YetkiliSifre { get; set; }
        private void UrunEkle()
        {

        }
        private void UrunCikar()
        {

        }
        private void UrunGüncelleme()
        {

        }
        private void MusteriTakip()
        {

        }
    }
}
