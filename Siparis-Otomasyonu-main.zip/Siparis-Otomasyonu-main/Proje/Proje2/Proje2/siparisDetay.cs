﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Proje2
{
    public class SiparisDetay
    {
        public int VergiDurumu { get; set; }
        public int miktar{ get; set; }
        public void AltToplamHesapla()
        {

        }
        public void AgırlıkHesapla()
        {

        }
        private List<Urun> Urunler = new List<Urun>();




    }
}
