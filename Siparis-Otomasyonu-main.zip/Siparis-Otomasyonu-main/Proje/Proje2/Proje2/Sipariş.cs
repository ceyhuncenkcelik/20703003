﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Proje2
{
    public class Siparis
    {
        
       
       
        public DateTime tarih { get; set; }
        public string durum { get; set; }
        public void VergiHesapla()
        {
            
        }
        public void ToplamHesapla()
        {

        }
        public void ToplamAgırlıkHesapla()
        {

        }
       
    }
}
